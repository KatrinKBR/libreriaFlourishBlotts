const librosDisponibles = []

// Inicializacion de los objetos, se guardan en el array
librosDisponibles.push(new Libro(1, 9780307743657,"The Shining","Stephen King","Anchor",8000,"../assets/theShining.jpg",4))
librosDisponibles.push(new Libro(2, 9788478712502,"Three Blind Mice","Agatha Christie","St. Martin S Press",10500,"../assets/threeBlindMice.jpg",2))
librosDisponibles.push(new Libro(3, 9780439362139,"Harry Potter and the Philosopher Stone","J.K. Rowling","Scholastic",9200,"../assets/hp1.jpg",2))
librosDisponibles.push(new Libro(4, 9781476727653,"Doctor Sleep","Stephen King","Scribner",9500,"../assets/doctorSleep.jpg",2))
